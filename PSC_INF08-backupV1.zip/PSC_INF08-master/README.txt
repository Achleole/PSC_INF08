Objectifs pour ce soir :
ÇA MARCHE
il faut donc
- créer le reaper (Arthur)
- écrire le code de l'ancêtre (Ariane)


Objectifs pour la semaine prochaine :
- créer une classe experiment (Ariane)
- gérer la mort correctement (par densité) (Lucas)
- renforcer l'analyse de données et trouver une bonne définition pour les individus/unités (Pierre, Yueh, Ariane)
